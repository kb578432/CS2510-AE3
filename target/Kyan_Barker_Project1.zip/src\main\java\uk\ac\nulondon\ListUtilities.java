package uk.ac.nulondon;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * offers helpful methods for working with lists.
 * many of the methods are just to make stream methods more concise.
 */
public class ListUtilities {
    /**
     * returns the first element in `list` which satisfies `predicate`, or null if no such element exists.
     */
    public static <T> T find(List<T> list, Predicate<T> predicate) {
        if (list == null || list.isEmpty()) return null;

        return list.stream()
                   .filter(predicate)
                   .findFirst()
                   .orElse(null);
    }

    /**
     * returns a list such that, for all indices `i`:
     * the i'th element of the list is the output of `initializer` applied to `i`.
     * inspired by kotlin's `List.init`
     */
    public static <T> List<T> initializeList(
            int listSize,
            Function<Integer, T> initializer
    ) {
        if (listSize < 0 || initializer == null) return List.of();

        List<T> list = new ArrayList<>();
        for (int index = 0; index < listSize; index++) {
            T element = initializer.apply(index);
            list.add(element);
        }
        return list;
    }

    /**
     * applies the `transformer` function to all elements of the argued 1d list.
     * implemented to reduce boilerplate associated with stream.
     */
    public static <I, O> List<O> map(
            List<I> list,
            Function<I, O> transformer
    ) {
        if (list == null || list.isEmpty()) return List.of();

        return list.stream()
                           .map(transformer)
                           .toList();
    }

    /**
     * applies the `transformer` function to all elements of the argued 2d list.
     * implemented to reduce boilerplate associated with stream.
     */
    public static <I, O> List<List<O>> map2D(
            List<List<I>> list,
            Function<I, O> transformer
    ) {
        if (list == null || list.isEmpty()) return List.of();

        Function<List<I>, List<O>> rowTransformer = row -> map(row, transformer);
        return map(list, rowTransformer);
    }

    /**
     * returns the sum of the argued list of integers.
     */
    public static int sum(List<Integer> integers) {
        if (integers == null || integers.isEmpty()) return 0;

        return integers.stream()
                       .mapToInt(Integer::intValue)
                       .sum();
    }

    /**
     * returns a transposed list. that is:
     * the i'th column of `list` is the i'th row of the transposed list.
     * the i'th row of `list` is the i'th column of the transposed list.
     */
    public static <T> List<List<T>> transpose(List<List<T>> list) {
        if (list == null || list.isEmpty()) return List.of();

        List<Integer> columnCounts = map(list, List::size);
        int maxColumnCount = Collections.max(columnCounts);
        List<List<T>> columns = initializeList(maxColumnCount, ArrayList::new);

        int rowCount = list.size();

        for (int rowIndex = 0; rowIndex < rowCount; rowIndex++) {
            List<T> row = list.get(rowIndex);
            int columnCount = row.size();
            for (int columnIndex = 0; columnIndex < columnCount; columnIndex++) {
                T element = row.get(columnIndex);
                List<T> column = columns.get(columnIndex);
                column.add(element);
            }
        }
        return columns;

    }
}
